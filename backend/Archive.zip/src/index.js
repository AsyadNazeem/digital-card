import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import sequelize from "./config/database.js";


// MODELS
import User from "./models/User.js";
import Company from "./models/Company.js";
import Contact from "./models/Contact.js";
import Request from "./models/Request.js";
import Admin from "./models/Admin.js";
import Theme from "./models/Theme.js";

// ROUTES
import authRoutes from "./routes/auth.js";
import dashboardRoutes from "./routes/dashboard.js";
import publicRoutes from "./routes/public.js";
import adminAuthRoutes from "./routes/adminAuth.js";
import adminRoutes from "./routes/admin.js";
import otpRoutes from "./routes/otp.js";
import settingsRoutes from "./routes/settings.js";
import themeRoutes from "./routes/theme.js";
import adminThemeRoutes from "./routes/adminTheme.js";


// PATH
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();
const app = express();

// Fix dirname for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// LOAD ALL MODELS FOR ASSOCIATIONS
const models = { User, Company, Contact, Request, Admin, Theme };

// RUN ALL ASSOCIATIONS
Object.values(models).forEach((model) => {
    if (model.associate) model.associate(models);
});

app.use(cors({ origin: process.env.FRONTEND_URL, credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Static storage for uploaded images (MOVED UP - must be before meta proxy)
app.use("/uploads", express.static(path.join(__dirname, "../uploads")));

// ============================================================================
// 🚨 ADD THIS NEW CODE HERE - Meta Proxy for Social Media Crawlers
// ============================================================================

app.get("/:mobile", async (req, res, next) => {
    const userAgent = req.headers['user-agent'] || '';

    // Check if request is from a social media crawler
    const isCrawler = /bot|crawler|spider|crawling|facebook|twitter|whatsapp|telegram|slack|linkedin|facebookexternalhit/i.test(userAgent);

    // If not a crawler, skip to next route
    if (!isCrawler) {
        return next();
    }

    try {
        let mobile = "+" + req.params.mobile;

        const contact = await Contact.findOne({
            where: { mobile, status: "active" }
        });

        if (!contact) {
            return next(); // Let other routes handle it
        }

        const company = await Company.findByPk(contact.companyId);

        if (!company) {
            return next();
        }

        const fullName = `${contact.firstName} ${contact.lastName}`;
        const title = `${fullName} - Digital Business Card`;
        const description = `Connect with ${fullName}${contact.designation ? ' - ' + contact.designation : ''} at ${company.companyName || 'TapMyName'}`;

        // Build full image URLs
        const baseUrl = process.env.BASE_URL || 'http://localhost:4000';
        const imageUrl = contact.photo
            ? `${baseUrl}${contact.photo}`
            : (company.logo ? `${baseUrl}${company.logo}` : `${baseUrl}/uploads/default-avatar.png`);

        const cardUrl = `${process.env.FRONTEND_URL || 'https://tapmy.name'}/${req.params.mobile}`;

        console.log('🤖 Crawler detected:', userAgent);
        console.log('📸 Serving meta tags with image:', imageUrl);

        // Send HTML with proper meta tags for social media
        const html = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${title}</title>
    
    <!-- Primary Meta Tags -->
    <meta name="title" content="${title}">
    <meta name="description" content="${description}">
    
    <!-- Open Graph / Facebook / WhatsApp -->
    <meta property="og:type" content="profile">
    <meta property="og:url" content="${cardUrl}">
    <meta property="og:title" content="${title}">
    <meta property="og:description" content="${description}">
    <meta property="og:image" content="${imageUrl}">
    <meta property="og:image:secure_url" content="${imageUrl}">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:site_name" content="TapMyName">
    
    <!-- Twitter -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:url" content="${cardUrl}">
    <meta name="twitter:title" content="${title}">
    <meta name="twitter:description" content="${description}">
    <meta name="twitter:image" content="${imageUrl}">
    
    <!-- Redirect after meta tags are read -->
    <meta http-equiv="refresh" content="1;url=${cardUrl}">
    
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .loading {
            text-align: center;
        }
        .spinner {
            border: 4px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top: 4px solid white;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="loading">
        <div class="spinner"></div>
        <h2>Loading ${fullName}'s Digital Business Card...</h2>
        <p>Redirecting you now...</p>
    </div>
    
    <script>
        // Immediate JavaScript redirect as fallback
        setTimeout(function() {
            window.location.href = "${cardUrl}";
        }, 100);
    </script>
</body>
</html>
        `;

        res.send(html);

    } catch (err) {
        console.error("❌ Error in meta proxy:", err);
        return next(); // Let other routes handle errors
    }
});

// ============================================================================
// END OF NEW CODE
// ============================================================================

// ROUTES (Keep these as they are)
app.use("/api/auth", authRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/public", publicRoutes);
app.use("/api/admin/themes", adminThemeRoutes);
app.use("/api/admin/auth", adminAuthRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/otp", otpRoutes);
app.use("/api/settings", settingsRoutes);
app.use("/api/themes", themeRoutes);

// HOME
app.get("/", (req, res) => {
    res.send("🚀 Express backend is running!");
});

// START SERVER
async function startServer() {
    try {
        await sequelize.authenticate();
        console.log("✅ Database connected successfully");

        await sequelize.sync();
        console.log("✅ Tables synchronized");

        app.listen(process.env.PORT || 4000, () => {
            console.log(`🚀 Server running on port ${process.env.PORT || 4000}`);
        });

    } catch (error) {
        console.error("❌ Database connection failed:", error);
    }
}

startServer();
